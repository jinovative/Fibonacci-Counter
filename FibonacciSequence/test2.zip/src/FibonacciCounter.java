/**
 * CS 5004
 * Lab 2-2
 * JinYoung Park
 * Fibonacci Counter
 */

public class FibonacciCounter {
  private final int count;

  /**
   * Constructs a FibonacciCounter object with the specified initial count.
   *
   * @param initialCount the initial count value
   * @throws IllegalArgumentException if the initial count is negative
   */
  public FibonacciCounter(int initialCount) {
    if (initialCount < 0) {
      throw new IllegalArgumentException("Initial count cannot be negative");
    }
    count = initialCount;
  }

  /**
   * Returns a new FibonacciCounter object with the count value incremented by 1.
   *
   * @return a new FibonacciCounter object with an incremented count
   * @throws IllegalStateException if the incremented count exceeds Integer.MAX_VALUE
   */
  public FibonacciCounter incremented() {
    int newCount = count + 1;
    if (newCount < 0) {
      throw new IllegalStateException("Counter overflow: Cannot increment count beyond Integer.MAX_VALUE");
    }
    return new FibonacciCounter(newCount);
  }

  /**
   * Returns a new FibonacciCounter object with the count value decremented by 1.
   *
   * @return a new FibonacciCounter object with a decremented count
   * @throws IllegalStateException if the decremented count is negative
   */
  public FibonacciCounter decremented() {
    int newCount = count - 1;
    if (newCount < 0) {
      throw new IllegalStateException("Counter underflow: Cannot decrement count below 0");
    }
    return new FibonacciCounter(newCount);
  }

  /**
   * Returns the current count value.
   *
   * @return the current count value
   */
  public int counter() {
    return count;
  }

  /**
   * Calculates and returns the Fibonacci number at the current count value.
   *
   * @return the Fibonacci number at the current count value
   */
  public int sequence() {
    if (counter() <= 1) {
      return count;
    }
    int prevPrevNum = 1;
    int prevNum = 1;
    int curNum = 0;
    for (int i = 3; i <= counter(); i++) {
      curNum = prevPrevNum + prevNum;
      prevPrevNum = prevNum;
      prevNum = curNum;
    }
    return curNum;
  }
}
