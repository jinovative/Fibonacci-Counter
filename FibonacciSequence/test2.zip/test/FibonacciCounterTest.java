import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class FibonacciCounterTest {

  @org.junit.Test
  public void testInitialCountNegative() {
    assertThrows(IllegalArgumentException.class, () -> new FibonacciCounter(-1));
  }


  @org.junit.Test
  public void testIncremented() {
    FibonacciCounter counter = new FibonacciCounter(7);
    FibonacciCounter incrementedCounter = counter.incremented();
    assertEquals(8, incrementedCounter.counter());
  }

  @org.junit.Test
  public void testIncrementedOverflow() {
    FibonacciCounter counter = new FibonacciCounter(Integer.MAX_VALUE);
    assertThrows(IllegalStateException.class, counter::incremented);
  }

  @org.junit.Test
  public void testDecremented() {
    FibonacciCounter counter = new FibonacciCounter(7);
    FibonacciCounter decrementedCounter = counter.decremented();
    assertEquals(6, decrementedCounter.counter());
  }

  @org.junit.Test
  public void testDecrementedUnderflow() {
    FibonacciCounter counter = new FibonacciCounter(0);
    assertThrows(IllegalStateException.class, counter::decremented);
  }

  @org.junit.Test
  public void testCounter() {
    FibonacciCounter counting = new FibonacciCounter(4);
    assertEquals(4, counting.counter());

  }

  @org.junit.Test
  public void testSequence() {
    FibonacciCounter counter1 = new FibonacciCounter(0);
    assertEquals(0, counter1.sequence());

    FibonacciCounter counter2 = new FibonacciCounter(1);
    assertEquals(1, counter2.sequence());

    FibonacciCounter counter3 = new FibonacciCounter(7);
    assertEquals(13, counter3.sequence());
  }
}